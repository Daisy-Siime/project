final String SIGN_IN = 'signin';
final String SIGN_UP ='signup';
final String WELCOME_SCREEN ='pages.welcomescreen';
final String GROUP_SCREEN ='groups';
final String SEARCH ='search';
final String MAP_SCREEN ='map';