import 'package:flutter/material.dart';

class Wallpapers extends StatefulWidget {
  const Wallpapers({Key? key}) : super(key: key);

  @override
  _WallpapersState createState() => _WallpapersState();
}

class _WallpapersState extends State<Wallpapers> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
