package com.example.snapchat_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
