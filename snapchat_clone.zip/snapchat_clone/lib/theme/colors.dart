import 'package:flutter/material.dart';

const Color primary = Color(0xFFe0c600);
const Color white = Color(0xFFFFFFFF);
const Color black = Color(0xFF000000);
const Color darkGrey = Color(0xFF6e717b);
const Color purple = Color(0xFFab67c3);
const Color blue = Color(0xFF0daff5);
const Color green = Color(0xFF5eb592);
