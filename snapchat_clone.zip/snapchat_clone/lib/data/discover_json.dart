const List quick_add_data = [
  {
    "img":
        "https://images.unsplash.com/photo-1553148661-9173d4786c6a?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=934&q=80",
    "name": "Minaya Cruz",
    "nickname": "minaya_cruz_zee"
  },
  {
    "img":
        "https://images.unsplash.com/photo-1610859923380-c8e5a13165d1?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    "name": "Dmitriy Frantsev",
    "nickname": "frantsev"
  },
  {
    "img":
        "https://images.unsplash.com/photo-1610917047732-7a4606dcc422?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80",
    "name": "Sebastian Mark",
    "nickname": "sebastian_mark"
  }
];

const List popular_star_data = [
  {
    "img":
        "https://media3.s-nbcnews.com/j/newscms/2019_48/3121616/191126-charli-damelio-cs-247p_6302ae62356bbac5ba52d17f82ba4dd0.fit-1240w.jpg",
    "name": "Charli D’amelio",
    "nickname": "damelioc"
  },
  {
    "img":
        "https://cdn.vox-cdn.com/thumbor/CkFiWYGtsCyF1VptcfMItm9w-2c=/1400x1050/filters:format(png)/cdn.vox-cdn.com/uploads/chorus_asset/file/16286694/Screen_Shot_2019_05_19_at_12.22.36_PM.png",
    "name": "James Charles",
    "nickname": "jamescharless"
  },
  {
    "img":
        "https://images.unsplash.com/photo-1610917047732-7a4606dcc422?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=934&q=80",
    "name": "Sebastian Mark",
    "nickname": "sebastian_mark"
  }
];

const List trending_lense_data = [
  {
    "img": "https://img.icons8.com/emoji/2x/chimpanzee-emoji.png",
    "name": "Smoke Flare VR",
    "nickname": "Vivek Thakur 🌴"
  },
  {
    "img":
        "https://images.unsplash.com/photo-1594745561149-2211ca8c5d98?ixid=MXwxMjA3fDB8MHxzZWFyY2h8NDZ8fGdpcmx8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    "name": "Purple World",
    "nickname": "Vivek Thakur 🌴"
  },
  {
    "img":
        "https://images.unsplash.com/photo-1502719414926-613118be79d3?ixid=MXwxMjA3fDB8MHxzZWFyY2h8Mnx8aWNlJTIwY29mZmVlfGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    "name": "Iced Coffee",
    "nickname": "Malcolm"
  }
];

const List popular_show_data = [
  {
    "img":
        "https://img.icons8.com/emoji/2x/man-with-mustache-light-skin-tone.png",
    "name": "5-Minute Crafts",
    "nickname": "Fun diy-projects, crafts, experience the joy..."
  },
  {
    "img":
        "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTF8fHBlb3BsZXxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    "name": "David Dobrik",
    "nickname": "Sexy, Gorgeous, and Humble"
  },
  {
    "img": "https://img.icons8.com/emoji/2x/television-emoji.png",
    "name": "Bitmoji TV",
    "nickname": "Starring you and your friends!"
  }
];
