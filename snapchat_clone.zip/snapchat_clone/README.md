# Snapchat Clone App UI

## [Download App Demo APK ⬇️📱](https://drive.google.com/file/d/1gXMP57Zne7q3Eyrji8qz2F7q4v006sMH/view)


- [Support me on Patreon](https://www.patreon.com/sopheamenvan?fan_landing=true)
- [Watch on youtube Part I](https://youtu.be/zCaNaKRXTbE)
- [Watch on youtube Part II](https://youtu.be/CYXKl58iTmA)
- [Watch on youtube Part III](https://youtu.be/YwU0TsjGvgE)
- [Watch on youtube Part IV](https://youtu.be/uHFNhZejD_Y)
- [Watch on youtube Part V](https://youtu.be/Zz7-lP9l7gc)

![App UI](https://user-images.githubusercontent.com/16510597/105662741-13ffbd80-5f03-11eb-95f6-0f0e61772536.jpg)

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
